package Controller;

public class NPCQuestController {

}
