package Controller;

public class HealthController {

    public void checkMaxHealth () {

    }
    public void faint () {}
    public void setHealth (int amount) {}
    public void advanceHealth (int amount) {}


}
