package Controller;

public class FishingController {
}
