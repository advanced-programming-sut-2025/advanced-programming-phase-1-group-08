package model;

public class MilkPail extends Tools {

    public void use (){}

}
