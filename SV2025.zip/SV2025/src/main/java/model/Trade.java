package model;

public class Trade {

    private User accountParty; // طرف حساب ترید کدوم پلیره؟
    // تابع make offer و receive offer
}
