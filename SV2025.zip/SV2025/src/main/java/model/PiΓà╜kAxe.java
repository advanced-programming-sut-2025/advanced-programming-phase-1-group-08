package model;

public class PiⅽkAxe extends Tools {

    public void use (){}

}
