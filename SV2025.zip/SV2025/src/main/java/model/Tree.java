package model;

import model.Enum.TreeType;

public class Tree extends GameObject {

    private TreeType Type;
    private String source; // بتونه تایپش عوض بشه بهتره
    private int level;
    private int ageByDay;


    public void changeLevel () {
    } // TODO  این باید تو تابعی که اول صبح کارا رو میکنه کال بشه




}