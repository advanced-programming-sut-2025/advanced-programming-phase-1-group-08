package model;

public class ForagingCrops extends Items{
}
