package model;

public class ForagingSeeds extends Items{
}
