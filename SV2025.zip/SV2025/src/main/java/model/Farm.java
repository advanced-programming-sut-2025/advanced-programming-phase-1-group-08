package model;

import java.util.ArrayList;

public class Farm {

    protected ArrayList<Tile> Farm = new ArrayList<>();

}
