package model;

public class Inventory {

    // TODO arrayList Item

}

