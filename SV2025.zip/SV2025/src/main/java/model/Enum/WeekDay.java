package model.Enum;

// برای روز های هفته


public enum WeekDay {

    monday, tuesday, wednesday, thursday, friday, saturday, sunday;

}
