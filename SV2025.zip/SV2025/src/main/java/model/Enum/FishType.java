package model.Enum;

public enum FishType {
}
