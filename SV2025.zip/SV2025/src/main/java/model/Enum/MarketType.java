package model.Enum;

public enum MarketType {
}
