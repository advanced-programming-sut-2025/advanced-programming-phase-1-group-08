package model.Enum;

public enum ForagingCropsType {
}
