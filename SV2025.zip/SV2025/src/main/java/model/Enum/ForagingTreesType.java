package model.Enum;

public enum ForagingTreesType {
}
