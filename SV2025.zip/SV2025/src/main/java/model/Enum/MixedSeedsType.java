package model.Enum;

public enum MixedSeedsType {
}
