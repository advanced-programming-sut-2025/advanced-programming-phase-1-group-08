package model.Enum;

public enum ForagingMineralsType {
}
