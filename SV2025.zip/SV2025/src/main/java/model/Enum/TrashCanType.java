package model.Enum;

public enum TrashCanType {

    primary{

    },
    coppery{

    },
    iron{

    },
    golden{

    },
    iridium{

    };

}
