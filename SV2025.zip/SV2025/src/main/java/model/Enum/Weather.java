package model.Enum;

public enum Weather {

    Sunny{
        public void doThings () {

        }
    },
    Rainy{
        public void doThings () {

        }
    },
    Stormy{
        public void doThings () {

        }
        public void strikeThunder () {
            // عدد رندوم باید بزاریم
        }
    },
    Snowy{
        public void doThings () {

        }
    };
}
