package model.Enum;

public enum ForagingSeedsType {
}
