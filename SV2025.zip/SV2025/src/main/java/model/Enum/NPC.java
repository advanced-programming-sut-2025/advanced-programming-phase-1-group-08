package model.Enum;

import model.Items;

public enum NPC {

    Sebastian,
    Abigail,
    Harvey,
    Lia,
    Robin;


    private Items favoriteItem;
    abstract boolean check (int id);
    abstract void NPCGifting ();

}
