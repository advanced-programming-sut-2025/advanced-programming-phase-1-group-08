package model.Enum;

public enum AnimalType {
    hen{
        // price
    },
    duck,
    rabbit,
    dino,


    cow,
    goat,
    sheep,
    pig;






}
