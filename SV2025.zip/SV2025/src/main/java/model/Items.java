package model;

public class Items extends GameObject {
}
