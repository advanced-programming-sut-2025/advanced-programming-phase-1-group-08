package model;

public class Axe extends Tools{

    public void use (){}
}
