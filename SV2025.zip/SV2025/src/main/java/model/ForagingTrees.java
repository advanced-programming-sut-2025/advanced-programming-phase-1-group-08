package model;

public class ForagingTrees extends Items {
}
