package model;

public class Market extends GameObject {
}
