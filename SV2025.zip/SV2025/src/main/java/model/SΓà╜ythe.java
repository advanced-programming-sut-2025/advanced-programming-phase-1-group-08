package model;

public class Sⅽythe extends Tools {

    public void use (){}
}
