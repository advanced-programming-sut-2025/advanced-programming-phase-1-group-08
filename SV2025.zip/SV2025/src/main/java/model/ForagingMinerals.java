package model;

public class ForagingMinerals extends Items{
}
