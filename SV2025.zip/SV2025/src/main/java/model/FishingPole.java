package model;

public class FishingPole extends Tools {

    public void use (){}

}
