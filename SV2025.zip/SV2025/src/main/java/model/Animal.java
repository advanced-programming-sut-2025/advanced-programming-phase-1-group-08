package model;

import model.Enum.AnimalType;

public class Animal extends GameObject {

    private AnimalType type;

}
