package model;

import java.util.ArrayList;

public class Home {
    private int width;
    private int length;
    private int topLeftX;
    private int topLeftY;
    ArrayList<String> machines = new ArrayList<>(); // دستگاه هایی که کرفت کردیم و میخواهیم با آنها فراوری یا کارهای دیگر بکنیم
}
