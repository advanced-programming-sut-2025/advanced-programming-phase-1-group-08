package model;

public class Hoe extends Tools {

    public void use (){}

}
