package model;

import model.Enum.TrashCanType;

public class TrashCan extends Tools {

    private TrashCanType Type;


    public void removeItem (){} // اسمش باید عوض یشه هم ورودی منابعی که باید برگردونده بشه رو بگیره و درصد برگشت هم که از تو اینام بدست میاد

}
