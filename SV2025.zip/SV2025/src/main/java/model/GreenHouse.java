package model;

public class GreenHouse {

    private final int requiredWood = 500;
    private final int requiredCoins = 1000;
    private final int length = 6; // بدون دیوار
    private final int width = 5; // بدوندیوار
    private final int coordinateX = -1; // برا اساس مپ عدد بدیم
    private final int coordinateY = -1; // برا اساس مپ عدد بدیم
    private int waterTank; // مقدار اب مخزن

    // اب پاش فراموش نشه


}
