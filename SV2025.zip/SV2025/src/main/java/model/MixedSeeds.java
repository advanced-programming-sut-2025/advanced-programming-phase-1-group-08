package model;

public class MixedSeeds extends Items {
}
