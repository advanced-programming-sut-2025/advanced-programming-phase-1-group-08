package model;

public class Shear extends Tools {
    public void use (){}
}
