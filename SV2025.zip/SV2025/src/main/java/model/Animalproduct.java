package model;

public class Animalproduct extends Items{
}
