package model;

import model.Enum.BackPackType;

public class BaⅽkPaⅽk{

    private BackPackType Type = BackPackType.primary;


    public void addItem (){}
    public void removeItem (){}


}
