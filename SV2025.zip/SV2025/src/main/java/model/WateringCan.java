package model;

public class WateringCan extends Tools {

    public void use (){}
}
