package model;

public class GameObject {

}
