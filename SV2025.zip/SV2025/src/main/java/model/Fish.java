package model;

public class Fish extends Items{
}
