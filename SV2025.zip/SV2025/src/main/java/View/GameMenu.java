package View;

import java.util.Scanner;

public class GameMenu implements AppMenu {
    @Override
    public void check(Scanner scanner) {

    }
}
