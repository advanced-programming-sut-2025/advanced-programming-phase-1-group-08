package View;

import java.util.Scanner;

public class RegisterMenu implements AppMenu{
    @Override
    public void check(Scanner scanner) {

    }
}
