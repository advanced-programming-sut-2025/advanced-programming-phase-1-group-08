package View;

import java.util.Scanner;

public class MarketMenu implements AppMenu {


    @Override
    public void check(Scanner scanner) {

    }
}
