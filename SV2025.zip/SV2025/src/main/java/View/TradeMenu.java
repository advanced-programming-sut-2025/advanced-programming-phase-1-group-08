package View;

public class TradeMenu {
}
